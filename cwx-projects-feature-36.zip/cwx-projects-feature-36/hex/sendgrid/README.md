# SendGrid Email Application on GKE

This is a simple application to send emails using SendGrid.

## Deployment Steps:

1. Build the Docker image: `docker build -t <your-docker-image-name> .`
2. Push the image to a registry.
3. Update the `deployment.yaml` with your image name.
4. Create the Kubernetes secret: `kubectl apply -f secret.yaml`
5. Deploy the app: `kubectl apply -f deployment.yaml`
