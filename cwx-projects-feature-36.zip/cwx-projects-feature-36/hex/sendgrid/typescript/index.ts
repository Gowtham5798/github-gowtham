import * as express from 'express';
import * as nodemailer from 'nodemailer';
import * as SendGridAPI from '@sendgrid/mail';
import * as dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('templates'));

const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY || '';
const SENDGRID_DEFAULT_SENDER = process.env.SENDGRID_DEFAULT_SENDER || 'ravi.prattipati@cloudwerx.tech';

const transport = nodemailer.createTransport({
    host: 'smtp.sendgrid.net',
    port: 465,
    secure: true,
    auth: {
        user: 'apikey',
        pass: SENDGRID_API_KEY
    }
});

app.get('/', (_req, res) => {
    res.render('index.html');  // Assuming you have a similar setup for rendering HTML templates
});

app.post('/send_email', async (req, res) => {
    const email_method = req.body.email_method;
    try {
        if (email_method === 'SMTP') {
            const message = {
                from: req.body.from,
                to: req.body.to.split(';'),
                cc: req.body.cc ? req.body.cc.split(',') : undefined,
                bcc: req.body.bcc ? req.body.bcc.split(',') : undefined,
                subject: req.body.subject,
                text: req.body.email_content
            };
            await transport.sendMail(message);
        } else if (email_method === 'WebAPI') {
            SendGridAPI.setApiKey(SENDGRID_API_KEY);
            const message = {
                to: req.body.to.split(';'),
                from: req.body.from,
                subject: req.body.subject,
                html: req.body.email_content
            };
            const response = await SendGridAPI.send(message);
            console.log(response[0].statusCode, response[0].body, response[0].headers);
        }
        console.log('Email sent successfully!');
        res.redirect('/');
    } catch (error) {
        console.error(`Error sending email: ${error}`);
        res.redirect('/');
    }
});

const PORT = 7890;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server started on http://0.0.0.0:${PORT}`);
});
