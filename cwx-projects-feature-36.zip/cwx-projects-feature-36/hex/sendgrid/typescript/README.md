# 💌 Node.js Email Application with Nodemailer (TypeScript)

A simple Node.js application written in TypeScript that leverages Nodemailer to send emails. Built with TypeScript and Express.

## 🚀 Getting Started

### 🐳 Using Docker

1. **Clone the repository**:
    ```bash
    git clone https://github.com/your-username/your-repo-name.git
    cd your-repo-name
    ```

2. **Build the Docker image**:
    ```bash
    docker build -t nodemailer-app .
    ```

3. **Run the Docker container**:
    ```bash
    docker run -p 3000:3000 nodemailer-app
    ```

4. **Access the application**:
    Navigate to `http://localhost:3000` in your browser.

### 💻 Without Docker

1. **Clone the repository**:
    ```bash
    git clone https://github.com/your-username/your-repo-name.git
    cd your-repo-name
    ```

2. **Install the dependencies**:
    ```bash
    npm install
    ```

3. **Compile the TypeScript**:
    ```bash
    tsc index.ts
    ```

4. **Start the application**:
    ```bash
    node index.js
    ```

5. **Access the application**:
    Navigate to `http://localhost:3000` in your browser.

## ⚙️ Configuration

This application requires several environment variables for proper functioning:

- `SMTP_HOST`: The SMTP host.
- `SMTP_PORT`: The SMTP port.
- `SMTP_USER`: SMTP user, typically an email address or API key username.
- `SENDGRID_API_KEY`: The API key for authentication.

You can set these variables in a `.env` file at the root of your project. Ensure you never commit the `.env` file to version control. Use a package like `dotenv` to load them when running the application.

## 📚 TypeScript Compilation

To compile the TypeScript code, you can use the TypeScript Compiler (`tsc`). 

1. **Compile the TypeScript code**:
    ```bash
    tsc index.ts
    ```

This will generate an `index.js` file which can be executed using Node.js.

## 🤝 Contributing

1. **Fork the repository** on GitHub.
2. **Clone the forked repo** on your machine.
3. **Create a new branch** to work on.
4. **Commit changes** to your branch.
5. **Push your changes** to your fork on GitHub.
6. **Open a pull request** from your fork to the original repository.

All contributions are welcome!

## 📄 License

This project is licensed under the MIT License. See the [LICENSE](./LICENSE) file for details.

## 🤖 Support & Contact

Should you encounter any issues or have questions, feel free to open an issue on GitHub. Alternatively, you can contact the maintainer at [youremail@example.com](mailto:youremail@example.com).
