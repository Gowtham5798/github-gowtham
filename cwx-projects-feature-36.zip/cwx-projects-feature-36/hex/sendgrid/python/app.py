from flask import Flask, render_template, request, redirect, flash
from flask_mail import Mail, Message
import os
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail as SGMail

app = Flask(__name__)

app.secret_key = os.environ.get('SECRET_KEY') or '$up3r$ecr3t'
app.config['MAIL_SERVER'] = 'smtp.sendgrid.net'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_USERNAME'] = 'apikey'
app.config['MAIL_PASSWORD'] = os.environ.get('SENDGRID_API_KEY')
app.config['MAIL_DEBUG'] = True
app.config['MAIL_DEFAULT_SENDER'] = os.environ.get('SENDGRID_DEFAULT_SENDER') or 'ravi.prattipati@cloudwerx.tech'

mail = Mail(app)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/send_email', methods=['POST'])
def send_email():
    email_method = request.form['email_method']
    try:
        if email_method == 'SMTP':
            msg = Message(request.form['subject'],
                          sender=request.form['from'],
                          recipients=request.form['to'].split(';'))
            msg.cc = request.form['cc'].split(',') if request.form['cc'] else []
            msg.bcc = request.form['bcc'].split(',') if request.form['bcc'] else []
            msg.body = request.form['email_content']
            mail.send(msg)
        elif email_method == 'WebAPI':
            message = SGMail(
                from_email=request.form['from'],
                to_emails=request.form['to'].split(';'),
                subject=request.form['subject'],
                html_content=request.form['email_content'])
            sg = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
            response = sg.send(message)
            print(response.status_code)
            print(response.body)
            print(response.headers)

        flash('Email sent successfully!')
    except Exception as e:
        flash(str(e))

    return redirect('/')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=7890)
