# CloudWerx Projects Repository

This repository contains multiple projects developed for CloudWerx on Google Cloud Platform (GCP). Each project is organized in its separate directory.

## Project Structure

- [encore](./encore) - Details specific to encore.
   - [encore/SubComponent1](./encore/SubComponent1) - Details about SubComponent1.
   - [encore/SubComponent2](./encore/SubComponent2) - Details about  SubComponent2.
- [hex](./hex) - Details specific to hex.
   - [hex/sendgrid](./hex/sendgrid) - Details about sendgrid sample.
- ... and so on for each project.

Each sub-directory has its own README with specific details of the project including objectives, GCP services used, and setup instructions.

## Contribution Guidelines

### Branching Strategy

- Main Branch: `main`
- Development Branch: `develop`

#### Feature Branches

- All new features should be developed in separate branches.
- Naming Convention: `feature/<feature-name>`
- Example: `feature/add-login`

#### Pull Requests (PRs)

- Once a feature is completed, create a PR to merge the feature branch into `develop`.
- PRs should be reviewed by at least one other team member.
- After all features are merged into `develop`, a final PR is made from `develop` to `main` to merge all changes.

#### Gitgraph Diagram

See below for Gitgraph Diagram on [Mermaid Live](https://mermaid.live/edit)
[![](https://mermaid.ink/img/pako:eNqdkkFLxDAQhf9KiNct0hxzFGGvonuSXGabaRtskppOBFn2v5tsu2hrUPQW3rz5JvOYE2-8Ri55VVXKkaEBJdsb2gcYe6YNdAGscpdqd5UPd1I5xljjrTW0fR4DuCb14hsOfpyrPTYvPtJKXHwtAsWAt_XauZEveGa0ZIrXihdEKKrHq1r6gcXQ4eekpWd6jTD1SzHNYgRd1h8e2U29xVkw7gtroS-kFf830g_RiHI04vu-ohSCKEYj_hCNKEUj1guJ_0dTIvFd9iSGTsd5yhzFqUeLimefxhbiQNl5TlaI5J_eXcMlhYg7HkcNhPfz-XLZwjAldQT37L2dTecPPNT5FA?type=png)](https://mermaid.live/edit#pako:eNqdkkFLxDAQhf9KiNct0hxzFGGvonuSXGabaRtskppOBFn2v5tsu2hrUPQW3rz5JvOYE2-8Ri55VVXKkaEBJdsb2gcYe6YNdAGscpdqd5UPd1I5xljjrTW0fR4DuCb14hsOfpyrPTYvPtJKXHwtAsWAt_XauZEveGa0ZIrXihdEKKrHq1r6gcXQ4eekpWd6jTD1SzHNYgRd1h8e2U29xVkw7gtroS-kFf830g_RiHI04vu-ohSCKEYj_hCNKEUj1guJ_0dTIvFd9iSGTsd5yhzFqUeLimefxhbiQNl5TlaI5J_eXcMlhYg7HkcNhPfz-XLZwjAldQT37L2dTecPPNT5FA)

```
---
title: GitGraph diagram
---
gitGraph TB:
   commit
   commit
   branch develop
   checkout develop
   branch feature/1
   checkout feature/1
   commit id: "1"
   commit id: "1a"
   commit id: "1b"
   checkout develop
   merge feature/1 id: "squash merge 1" tag: "PR #1"
   checkout main
   merge develop id: "merge feature1" tag: "PR #1"
   checkout develop
   branch feature/2
   checkout feature/2
   commit id: "2"
   commit id: "2a"
   commit id: "2b"
   checkout develop
   merge feature/2 id: "squash merge 2" tag: "PR #2"
   checkout main
   merge develop id: "merge feature2" tag: "PR #2"


```

## Getting Started

To contribute to a project:
1. Clone the repository.
2. Checkout to the `develop` branch.
3. Create a new feature branch from `develop`.
4. After development, push the feature branch and create a PR to `develop`.
5. Ensure that your code adheres to the project's standards and passes all tests.

### Before Starting Feature Development

**Important Note:** Before beginning development on a new feature, please ensure to:

1. Create a new [GitHub issue](https://github.com/eximietasdesign/cwx-projects/issues) in the repository, describing the feature's purpose, requirements, and any relevant details.
2. Link the issue in your feature branch and pull request using [Conventional Commit](https://www.conventionalcommits.org/en/v1.0.0/#summary)
3. Discuss and clarify any questions or suggestions in the issue thread.

This process helps in maintaining a clear and trackable workflow for new features and ensures that all team members are informed and aligned.


## Reporting Issues

Please use the issue tracker to report issues or suggest enhancements.

For more information or queries, please contact the repository maintainers 
- [Parthiban Siddharthan](mailto:parthiban@eximietas.design)
- [Srikant Tirumalai](mailto:srikant@eximietas.design)
- [Ravi Prattipati](mailto:ravi@eximietas.design) 
- [Saravanan Mani](mailto:saravanan.mani@eximietas.design)
