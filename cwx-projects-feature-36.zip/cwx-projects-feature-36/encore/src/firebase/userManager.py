import sys
import logging
import os
import time
import csv
import inspect
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
from firebase_admin import auth
from firebase_admin import exceptions

__debugMode = (os.environ.get('CWX_DEBUG') == 'True') or False
__logDir = os.environ.get('CWX_LOG_DIR') or '.'

class FireBaseUserManager:
    """This class supports initializing firebase auth API with a service account token and performing user management operations
    Attributes:
        importedCsvUsers : sequence
            list of user objects read in from configured CSV file
        userCsvLocation : str
            file path location of CSV file
    """

    def __init__(self, tokenFile):
        """Initialize the Firebase user manager with the service token JWT"""

        func_name = sys._getframe().f_code.co_name
        self.logger = logging.getLogger('FireBaseUserManager')
        self.tokenLocation = tokenFile
        self.logger.debug('{0}: Token location to read: {1}'.format(func_name, tokenFile))
        self.cred = credentials.Certificate(self.tokenLocation)
        self.logger.debug('{0}: Firebase credential for {1}'.format(func_name, self.cred.service_account_email))
        self.userMgmtApp = firebase_admin.initialize_app(self.cred)
        self.logger.debug('{0}: Firebase app initialized for project id {1}'.format(func_name, self.userMgmtApp.project_id))

    def createUser(self, userProfile):
        func_name = sys._getframe().f_code.co_name
        try:
            user = auth.create_user(
                email = userProfile['email'],
                phone_number = userProfile['phone'],
                display_name = userProfile['username']
            )
            self.logger.debug('{0}: Created user with uuid {1}, email {2}, phone {3}, name {4}'.format(func_name, 
                                                                                                  user.uid, 
                                                                                                  user.email, 
                                                                                                  user.phone_number, 
                                                                                                  user.display_name))
        except ValueError as ve:
            self.logger.error('{0}: Invalid user properties',format(func_name) + ve)
        except exceptions.FireBaseError as fbe:
            self.logger.error('{0}: Failed to create user in Firebase. {1}'.format(func_name, fbe))
        return user

    def setCSVLocation(self, userCSV):
        self.userCsvLocation = userCSV

    def importUsers(self):
        """Imports a CSV file into memory and creates a sequence of user profiles
        The CSV file has values in this format
            id,name,username,email,phone,...
        """

        func_name = sys._getframe().f_code.co_name
        self.importedCsvUsers = []
        
        try:
            with open(self.userCsvLocation, mode='r', newline='') as csv_file:
                reader = csv.DictReader(csv_file)
                for row in reader:
                    record = {
                        'id': row['id'],
                        'name': row['name'],
                        'username': row['username'],
                        'email': row['email'] if row['email']!='NULL' else None,
                        'phone': row['phone']
                    }
                    [self.logger.debug(f"{func_name}: {key}: {value}") for key, value in record.items()]
                    self.importedCsvUsers.append(record)
            self.logger.info('{0}: Read {1} records from CSV file {2}'.format(func_name, len(self.importedCsvUsers), self.userCsvLocation))
            return self.importedCsvUsers
        except FileNotFoundError:
            self.logger.error('{0}: CSV File not found: {1}'.format(func_name, self.userCsvLocation))
        except Exception as e:
            self.logger.error("{0}: An error occurred reading CSV file: {1}".format(func_name, e))
        return None
    
    def createFirebaseUsers(self):
        """
        Performs bulk user import of user records into Firebase Authentication user store
        FB has a 1K limit.
        """
        func_name = sys._getframe().f_code.co_name
        firebirdUsers = []
        ## need to add a check to limit to < 1000 users since Firebird doesn't support larger imports
        for importedUser in self.importedCsvUsers:
            self.logger.debug('{0}: Processing user id {1}'.format(func_name, importedUser))
            firebirdUsers.append(
                auth.ImportUserRecord(
                    uid = importedUser['id'],
                    display_name = importedUser['username']  or None,
                    email = importedUser['email'] if importedUser['email']!='NULL' else None,
                    phone_number = importedUser['phone'] if importedUser['phone']!='NULL' else None
                )
            )
        
        try:
            importResult = auth.import_users(firebirdUsers)
            self.logger.info('{0}: Successfully imported {1} users into Firebase'.format(func_name, importResult.success_count))
            for error in importResult.errors:
                self.logger.warning('{0}: Failed to create user record for index {1} with reason {2}'.format(func_name, error.index, error.reason))
        except exceptions.FirebaseError as ex:
            self.logger.error('{0}: Importing users into Firebase failed: {1}'.format(func_name, ex))

        return

def main():
    func_name = sys._getframe().f_code.co_name
    if __debugMode:
        logLevel = logging.DEBUG
        print('Current log level set to: {0}'.format(logLevel))
    else:
        logLevel = logging.INFO
    logfile = __logDir + '/FireBaseUserManager-{0}.log'.format(int(time.time()))
    if __debugMode:
        print('All logging output will go to {0}'.format(logfile))

    svcTokenFile = os.environ.get('CWX_SVC_TOKEN') or './cwx_svc_token.json'
    fbUsersCsvPath = os.environ.get('CWX_FIREBASE_USERS') or './data/firebaseusers.csv'

    try:
        logging.basicConfig(filename=logfile, level=logLevel)
        logging.info('{0}: # log file for FireBaseUserManager started {1}'.format(func_name, time.ctime()))
        logging.info('{0}: Looking for service token in file: {1}'.format(func_name, svcTokenFile))

        userManager = FireBaseUserManager(svcTokenFile)
        userManager.setCSVLocation(fbUsersCsvPath)
        userManager.importUsers()
        userManager.createFirebaseUsers()
    except Exception as err:
        logging.error(err)
    return


if __name__ == "__main__":
    main()