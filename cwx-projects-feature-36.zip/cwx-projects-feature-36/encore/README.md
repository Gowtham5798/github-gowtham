# cwx-projects
Cloudwerx related projects, utilities and code


## Firebase user management 
This script is capable of processing a CSV file as input and creating corresponding users for Google Firebase authentication.

### Configuration
The script at this time does not take any command line inputs. Instead it uses environment variables
| Property Name | Value | Default | Description |
| ------------- | ----------- | ----------- | ----------- |
| CWX_DEBUG     | True or False | True | Enables debug logging |
| CWX_LOG_DIR | `</path/to/existing/directory>` | current directory | All log files will be created in this location.  |
| CWX_SVC_TOKEN | `</path/to/service_token/file>` | `./cwx_svc_token.json` | Create a service account token in GCP console corresponding to firebase service account and download to file system where script will execute|
| CWX_FIREBASE_USERS | `</path/to/csv_file>` | `./data/firebaseusers.csv` | The CSV file which has list of users to create in Firebase|

### Google Cloud Configuration - Obtaining service token
Here are step by step instructions on how to create a service account token to be used with the script.
1. Traverse your Google cloud console to the Identity and Access Management section
![IAM Service Account](img/IAM-ServiceAccount.png "IAM Service Account")
2. Select the "Service Account" option
3. Search for the Firebase service account and select the option to manage Keys
![Key For Firebase Svc Account](img/FirebaseSvcAccountKeyMgmt.png "Key Management For Firebase Service Account")
4. Create a new key for the service account
![Create new key](img/CreateNewKey.png "Create New Key")
5. Select JSON private key format and store the downloaded file securely on local filesystem
![Select JSON Private Key option](img/JsonKey.png "Select JSON Private Key option")

### Logging and Diagnostics
By default, logging level is set to `INFO`. The `CWX_DEBUG` variable enables the logging level to be set to `DEBUG`. The output
will look similar to the below example
```
DEBUG:FireBaseUserManager:__init__: Firebase app initialized for project id <some-project-id>
INFO:FireBaseUserManager:importUsers: Read 3 records from CSV file <some filename>
ERROR:root:Invalid email: "". Email must be a non-empty string.
```


### To-Do's
- [ ] quality: Input data validation improvements - space trimming, empty strings, etc.
- [ ] enhancement: process config as command-line arguments